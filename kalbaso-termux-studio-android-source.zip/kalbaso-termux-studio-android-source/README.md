# KALBASO Termux Studio (Android Native IDE) 🚀

![KALBASO Icon](app_icon.jpg)

**KALBASO Termux Studio** هو تطبيق أندرويد أصلي (Native Kotlin) وبيئة تطوير متكاملة (IDE) مصممة خصيصاً لمطوري **Termux**.
يهدف التطبيق إلى تسريع وتسهيل بناء أدوات بايثون التفاعلية للطرفية، مع قوالب واجهات جاهزة، ومدير حزم ومكتبات بايثون بنقرة واحدة، وربط مباشر وحقيقي مع تطبيق Termux عبر `com.termux.permission.RUN_COMMAND`.

---

## 🌟 الميزات الرئيسية (Features)

1. **قوالب الواجهات الجاهزة (3 UI Templates):**
   - **Classic:** واجهة نصية نظيفة، خفيفة جداً، وسريعة مع دعم ألوان ANSI القياسية.
   - **Cyberpunk:** واجهة نيون عصرية، إطارات Glitch، أشرطة تحميل ASCII متحركة ومظهر تيرمكس المستقبلي.
   - **Dashboard:** واجهة جداول ومنظمات بيانات ولوحات تحكم لعرض إحصائيات النظام ومراقبة الموارد.

2. **مدير مكتبات بايثون (Python Package Manager):**
   - قائمة متكاملة بالمكتبات الأساسية: `requests`, `colorama`, `rich`, `beautifulsoup4`, `pandas`, `flask`, `pyfiglet`, `psutil`...
   - إرسال أمر التثبيت التلقائي إلى تيرمكس مباشرة عبر `Intent` دون الحاجة لكتابة الأوامر يدوياً.
   - إنشاء ملف `requirements.txt` وسكربت `install.sh` تلقائياً.

3. **مولد الكود الفوري (Code Generator):**
   - توليد كود بايثون نظيف ومحكم 100% جاهز للعمل من أول مرة.
   - تخصيص اسم الأداة، المطور، الشعار النصي ASCII، والقوائم التفاعلية.

4. **ربط تيرمكس الحقيقي (Termux RUN_COMMAND Integration):**
   - إرسال الأوامر وتشغيل السكربتات مباشرة داخل بيئة تيرمكس الأصلية.

---

## 📲 التثبيت المباشر للـ APK

يمكنك تنزيل ملف الـ APK الجاهز مباشرة من مجلد الإصدارات [Releases](../../releases) أو من خلال التطبيق:
- اسم الملف: `KALBASO-Termux-Studio.apk`
- التوافق: Android 7.0 وما فوق (API 24+).

### تفعيل الربط في Termux:
لكي يتمكن التطبيق من إرسال الأوامر إلى Termux:
1. افتح Termux واكتب:
```bash
mkdir -p ~/.termux
echo "allow-external-apps = true" >> ~/.termux/termux.properties
termux-reload-settings
```

---

## 🛠️ البناء من المصدر (Building from Source)

```bash
# استنساخ المستودع
git clone https://github.com/YOUR_USERNAME/kalbaso-termux-studio.git
cd kalbaso-termux-studio

# بناء حزمة APK للإصدار
./gradlew assembleRelease
```

---

## 📄 الترخيص (License)
هذا المشروع مفتوح المصدر بالكامل تحت رخصة **MIT License**.
