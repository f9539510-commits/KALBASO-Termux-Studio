package com.kalbaso.termuxstudio

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast

/**
 * TermuxBridge: Sends authentic Android Intents to Termux:API and RunCommandService
 */
class TermuxBridge(private val context: Context) {

    companion object {
        const val TERMUX_PACKAGE = "com.termux"
        const val TERMUX_SERVICE = "com.termux.app.RunCommandService"
        const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"

        const val EXTRA_RUN_COMMAND_PATH = "com.termux.RUN_COMMAND_PATH"
        const val EXTRA_RUN_COMMAND_ARGUMENTS = "com.termux.RUN_COMMAND_ARGUMENTS"
        const val EXTRA_RUN_COMMAND_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR"
        const val EXTRA_RUN_COMMAND_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND"
        const val EXTRA_RUN_COMMAND_SESSION_ACTION = "com.termux.RUN_COMMAND_SESSION_ACTION"

        const val PIP_PATH = "/data/data/com.termux/files/usr/bin/pip"
        const val BASH_PATH = "/data/data/com.termux/files/usr/bin/bash"
        const val HOME_DIR = "/data/data/com.termux/files/home"
    }

    fun isTermuxInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(TERMUX_PACKAGE, PackageManager.GET_ACTIVITIES)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Executes 'pip install <package>' directly in Termux
     */
    fun installPipPackage(packageName: String) {
        if (!isTermuxInstalled()) {
            Toast.makeText(context, "تيرمكس غير مثبت على جهازك", Toast.LENGTH_LONG).show()
            return
        }

        val intent = Intent(ACTION_RUN_COMMAND).apply {
            setClassName(TERMUX_PACKAGE, TERMUX_SERVICE)
            putExtra(EXTRA_RUN_COMMAND_PATH, PIP_PATH)
            putExtra(EXTRA_RUN_COMMAND_ARGUMENTS, arrayOf("install", packageName))
            putExtra(EXTRA_RUN_COMMAND_WORKDIR, HOME_DIR)
            putExtra(EXTRA_RUN_COMMAND_BACKGROUND, false)
            putExtra(EXTRA_RUN_COMMAND_SESSION_ACTION, "0") // Open in foreground terminal
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            Toast.makeText(context, "تم إرسال أمر تثبيت $packageName لتيرمكس!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // Fallback to opening Termux directly
            openTermuxFallback()
        }
    }

    /**
     * Writes python script and launches it in Termux
     */
    fun deployPythonScript(fileName: String, scriptContent: String) {
        val safeName = fileName.replace(" ", "_").lowercase() + ".py"
        val shellCommand = "cat << 'EOF' > ~/$safeName\n$scriptContent\nEOF\npython ~/$safeName"

        val intent = Intent(ACTION_RUN_COMMAND).apply {
            setClassName(TERMUX_PACKAGE, TERMUX_SERVICE)
            putExtra(EXTRA_RUN_COMMAND_PATH, BASH_PATH)
            putExtra(EXTRA_RUN_COMMAND_ARGUMENTS, arrayOf("-c", shellCommand))
            putExtra(EXTRA_RUN_COMMAND_WORKDIR, HOME_DIR)
            putExtra(EXTRA_RUN_COMMAND_BACKGROUND, false)
            putExtra(EXTRA_RUN_COMMAND_SESSION_ACTION, "0")
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            Toast.makeText(context, "تم إنشاء وتشغيل $safeName في تيرمكس!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            openTermuxFallback()
        }
    }

    private fun openTermuxFallback() {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(TERMUX_PACKAGE)
        if (launchIntent != null) {
            context.startActivity(launchIntent)
        }
    }
}
