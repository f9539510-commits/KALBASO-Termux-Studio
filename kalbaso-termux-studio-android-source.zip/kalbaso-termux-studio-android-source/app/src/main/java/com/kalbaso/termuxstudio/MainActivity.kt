package com.kalbaso.termuxstudio

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.kalbaso.termuxstudio.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

/**
 * KALBASO Termux Studio - Native Android IDE
 * Developed for Termux Developers with Native RUN_COMMAND Intents
 * Open-Source under MIT License
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var termuxBridge: TermuxBridge
    private val selectedPackages = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        termuxBridge = TermuxBridge(this)

        setupUI()
        checkTermuxEnvironment()
    }

    private fun setupUI() {
        // فحص بيئة تيرمكس
        binding.btnCheckTermux.setOnClickListener {
            checkTermuxEnvironment()
        }

        // تثبيت حزمة بايثون المحددة عبر تيرمكس
        binding.btnInstallPackage.setOnClickListener {
            val pkgName = binding.etPackageName.text.toString().trim()
            if (pkgName.isNotEmpty()) {
                termuxBridge.installPipPackage(pkgName)
            } else {
                Toast.makeText(this, "يرجى كتابة اسم الحزمة أولاً", Toast.LENGTH_SHORT).show()
            }
        }

        // إرسال الكود المولد مباشرة إلى تيرمكس
        binding.btnPushToTermux.setOnClickListener {
            val toolName = binding.etToolName.text.toString().ifEmpty { "my_kalbaso_tool" }
            val generatedCode = CodeGenerator.buildTool(
                toolName = toolName,
                author = binding.etAuthor.text.toString().ifEmpty { "Termux Dev" },
                template = binding.spinnerTemplate.selectedItem.toString()
            )
            termuxBridge.deployPythonScript(toolName, generatedCode)
        }
    }

    private fun checkTermuxEnvironment() {
        val isInstalled = termuxBridge.isTermuxInstalled()
        if (isInstalled) {
            binding.tvTermuxStatus.text = "تيرمكس مثبت وجاهز للربط ✓"
            binding.tvTermuxStatus.setTextColor(getColor(R.color.neon_green))
        } else {
            binding.tvTermuxStatus.text = "تيرمكس غير مثبت على الهاتف ✗"
            binding.tvTermuxStatus.setTextColor(getColor(R.color.neon_red))
        }
    }
}
