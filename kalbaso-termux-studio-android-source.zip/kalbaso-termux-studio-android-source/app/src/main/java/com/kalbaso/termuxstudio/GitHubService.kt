package com.kalbaso.termuxstudio

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Base64

class GitHubService(private val token: String, private val username: String) {

    private val client = OkHttpClient()

    /**
     * فحص التوكن واختبار الاتصال بـ GitHub API
     */
    suspend fun testConnection(): Result<JSONObject> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("https://api.github.com/user")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github.v3+json")
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: "{}"
                    Result.success(JSONObject(body))
                } else {
                    Result.failure(Exception("GitHub error code: ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * رفع ملف بايثون مباشرة إلى مستودع المطور في GitHub
     */
    suspend fun pushFile(repoName: String, fileName: String, content: String): Result<String> = withContext(Dispatchers.IO) {
        val url = "https://api.github.com/repos/$username/$repoName/contents/$fileName"
        val encodedContent = Base64.getEncoder().encodeToString(content.toByteArray(Charsets.UTF_8))
        
        val jsonPayload = JSONObject().apply {
            put("message", "Add $fileName via KALBASO Termux Studio")
            put("content", encodedContent)
            put("branch", "main")
        }

        val requestBody = jsonPayload.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .put(requestBody)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github.v3+json")
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful || response.code == 201) {
                    Result.success("https://github.com/$username/$repoName/blob/main/$fileName")
                } else {
                    Result.failure(Exception("HTTP ${response.code}: ${response.body?.string()}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
