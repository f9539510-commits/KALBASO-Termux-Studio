package com.kalbaso.termuxstudio

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class PyPiResult(
    val name: String,
    val version: String,
    val summary: String,
    val arabicInsight: String?,
    val homePage: String?
)

/**
 * Smart PyPI Search Engine for Native Android:
 * Handles Arabic semantic mappings and queries https://pypi.org/pypi/{package}/json via OkHttp
 */
class PyPiSearchService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    private val arabicKeywords = mapOf(
        "طلبات" to listOf("requests", "httpx", "aiohttp"),
        "تلوين" to listOf("colorama", "rich", "termcolor"),
        "جداول" to listOf("rich", "tabulate", "prettytable"),
        "كشط" to listOf("beautifulsoup4", "lxml", "scrapy"),
        "خادم" to listOf("flask", "fastapi", "uvicorn"),
        "بيانات" to listOf("pandas", "numpy", "scipy"),
        "تشفير" to listOf("cryptography", "pycryptodome"),
        "واجهة" to listOf("click", "prompt_toolkit", "rich"),
        "موارد" to listOf("psutil")
    )

    suspend fun searchPackage(query: String): List<PyPiResult> = withContext(Dispatchers.IO) {
        val trimmed = query.trim().lowercase()
        val candidates = mutableListOf<String>()

        // Check Arabic mapping
        for ((arWord, pkgs) in arabicKeywords) {
            if (trimmed.contains(arWord)) {
                candidates.addAll(pkgs)
            }
        }

        // Add direct query if english
        if (trimmed.matches(Regex("^[a-zA-Z0-9_-]+$"))) {
            if (!candidates.contains(trimmed)) {
                candidates.add(0, trimmed)
            }
        }

        val results = mutableListOf<PyPiResult>()
        for (pkg in candidates.distinct().take(6)) {
            val res = fetchFromPyPi(pkg)
            if (res != null) {
                results.add(res)
            }
        }
        results
    }

    private fun fetchFromPyPi(packageName: String): PyPiResult? {
        val url = "https://pypi.org/pypi/$packageName/json"
        val request = Request.Builder().url(url).build()

        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                val json = JSONObject(body)
                val info = json.getJSONObject("info")

                PyPiResult(
                    name = info.optString("name", packageName),
                    version = info.optString("version", "latest"),
                    summary = info.optString("summary", "Python package from official PyPI"),
                    arabicInsight = if (packageName == "requests") "مكتبة طلبات HTTP والـ APIs" else null,
                    homePage = info.optString("home_page", "https://pypi.org/project/$packageName/")
                )
            }
        } catch (e: Exception) {
            null
        }
    }
}
